import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Arrays;

public class Main {

  public static void main (String args[]) {
    MyFrame f= new MyFrame();
  }


}
