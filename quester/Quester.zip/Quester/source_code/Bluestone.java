import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;



public class Bluestone extends Item {
  public Bluestone () {
    super("images/bluestone.png", 6, 10);
  }
}
