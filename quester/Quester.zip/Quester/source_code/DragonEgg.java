import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;



public class DragonEgg extends Item {
  public DragonEgg () {
    super("images/dragonegg.png", 7, 2);
  }
}
