import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;



public class Ruby extends Item {
  public Ruby () {
    super("images/ruby.png", 4, 10);
  }
}
