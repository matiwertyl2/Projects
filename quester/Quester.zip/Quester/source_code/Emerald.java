import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;



public class Emerald extends Item {
  public Emerald () {
    super("images/emerald.png", 5, 10);
  }
}
