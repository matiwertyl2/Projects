import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Vector;
import java.util.Random;
import java.util.Arrays;



public class Rock extends Item {
  public Rock () {
    super("images/rock.png", 2, 10);
  }
}
